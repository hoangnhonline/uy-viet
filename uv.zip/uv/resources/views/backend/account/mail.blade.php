<p>Hi {{ $fullname }}!</p>

<p>Chào mừng bạn đến với hệ thống quản trị nhadat.vn</p>

<p>Sau đây là thông tin đăng nhập của bạn:</p>
URL : <a href="http://cahatvui.com/admin/login">http://cahatvui.com/admin/login</a> <br>
Email : <strong>{{ $email }}</strong><br>
Password : <strong>{{ $password }}</strong>

<p>Vì lý do bảo mật, vui lòng thay đổi mật khẩu của bạn sau lần đầu tiên đăng nhập vào hệ thống.</p>