<p>Hi {{ $full_name }}!</p>

<p>Chào mừng bạn đến với hệ thống quản trị phim1p.com.</p>

<p>Sau đây là thông tin đăng nhập của bạn:</p>
URL : <a href="http://phim1p.com/admin/login">http://phim1p.com/admin/login</a> <br>
Email : <strong>{{ $email }}</strong><br>
Password : <strong>{{ $password }}</strong>

<p>Vì lý do bảo mật, vui lòng thay đổi mật khẩu của bạn sau lần đầu tiên đăng nhập vào hệ thống.</p>