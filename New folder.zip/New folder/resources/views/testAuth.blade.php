<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="redirect">FB Login</a>
</body>
</html>