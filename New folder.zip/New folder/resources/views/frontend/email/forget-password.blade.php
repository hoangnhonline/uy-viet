<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mail</title>
</head>
<body>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="600" bgcolor="#dcf0f8" style="margin:0;padding:0;background-color:#f2f2f2;width:100%!important;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px">
  <tbody>
    <tr>

      <td align="center" valign="top" style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#444;line-height:18px;font-weight:normal">
        <h3>Chào quý khách,</h3>
        <p>annammobile.com đã nhận được yêu cầu thay đổi mật khẩu của quý khách.</p>
        <p>Xin hãy click vào đường dẫn sau để đổi mật khẩu:</p>
        <a>https://tiki.vn/customer/account/reset_password?key=c8f52212868331cc39337bb9e7136a6d</a>
        <p>Mọi thắc mắc và góp ý vui lòng liên hệ với chúng tôi qua email: support@annammobile.com hoặc số điện thoại 1900 636 975 (8-21h cả T7,CN).</p>
        <p>Trân trọng, </p>
        <p>annammobile.com</p>
      </td>
    </tr>    
  </tbody>
</table>

</body>
</html>