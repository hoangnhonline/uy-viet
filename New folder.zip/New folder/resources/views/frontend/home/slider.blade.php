@section('slider')
<div id="home-slider">

</div>
@endsection